package io.javabrains.springbootstarter.coreJava.thread;


public class Print100 {
    public static void main(String[] args) {
        System.out.println("##################Main thread starts here");
        Thread t1=new Thread(new Thread100());
        t1.start();
        synchronized (t1) {
            try {
                t1.wait();
            } catch(InterruptedException e){
                e.printStackTrace();
            }
        }
        Thread t2=new Thread(new Thread100());
        t2.start();
        synchronized (t2) {
            try {
                t2.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("##################Mian thread ends here");
    }
}

class Thread100 implements Runnable {

    private static int count =0;
    private int id;
    @Override
    public void run() {
        synchronized (this) {
            for (int i = 1; i <= 9; i++) {
                System.out.println("Thread <" + id + "> Printing" + i);
                /*try {
                    TimeUnit.MILLISECONDS.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }*/
            }
            notify();
        }
    }

    public Thread100() {
        this.id=++count;
    }
}
