package io.javabrains.springbootstarter.coreJava.sapientOnlineTest;

public class Ques7 {
    public static void main(String[] args) throws Exception
    {
        /*Integer[][] ints = { { 1, 2, 3 }, { null }, { 7, 8, 9 } };
        System.out.println("value = " + ints[1][1].intValue());*/


    }
}
