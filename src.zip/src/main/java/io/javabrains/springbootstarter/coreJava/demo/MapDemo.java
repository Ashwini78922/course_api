package io.javabrains.springbootstarter.coreJava.demo;


import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class MapDemo {
    public static void main(String[] args) {
        //Map interface implements HashMap, LinkedHashMap and TreeMap

        HashMap hMap = new HashMap();
        hMap.put(null, "r");
        hMap.put(null, 5);
        hMap.put(1, "A");
        hMap.put(2, "D");
        hMap.put(3, 4);
        hMap.put("A", "L");
        System.out.println(hMap);

        LinkedHashMap lMap =new LinkedHashMap();
        lMap.put(null, "f");
        lMap.put(null, 3); // duplicate key r not allowed, it will replace the existing value.
        lMap.put(1, "A");
        lMap.put(2, "D");
        lMap.put(3, 4);
        lMap.put("A","L");
        lMap.put(5, null);
        lMap.put(9, null);
        System.out.println(lMap);

        TreeMap tMap =new TreeMap();
        //tMap.put(null, "j"); // throw NPE
        tMap.put(7, null);
        tMap.put(9, null);
        tMap.put(1, "A");
        tMap.put(2, "D");
        tMap.put(3, 4);
        //tMap.put("A","L");
        System.out.println(tMap.putIfAbsent(3, 8));
        System.out.println(tMap.firstEntry());
        System.out.println(tMap);

    }
}
