package io.javabrains.springbootstarter.coreJava.demo;


public class JavaDemo {

    public static void main(String[] args) {

        /*//Left Pyramid
        char a[]= new char[5];
        for(int i=0; i<a.length; i++) {
            for(int j=0; j<=i; j++) {
                a[i] = 'a';
                System.out.print(a[i]+" ");
            }
            System.out.println();
        }

        //Right Pyramid
        //char b='b';
        for(int i=0; i<5;i++){
            int j;
            for(j=4;j>i;j--){
                System.out.print("  ");
            }
            for(int k=0; k<=i; k++){
                System.out.print('b'+ " ");
            }
            System.out.println();
        }

        //Center Pyramid
        for(int i=1; i<=5; i++){
            for(int j=5; j>i; j--){
                System.out.print("  ");
            }
            for(int k=1; k<=(i*2-1); k++){
                System.out.print('c'+ " ");
            }
            System.out.println();
        }

        //Fibonacci Series w/o recursion
        long num1=0, num2=1, num3;
        Scanner sc = new Scanner(System.in);
        System.out.println("\n Enter fibonacci limit: ");
        int fibLength=sc.nextInt();
        System.out.println("FIBONACCI SERIES: ");

        System.out.print(num1+ " ");
        System.out.print(num2+ " ");
        for (int i=2; i<fibLength; i++){
            num3=num1+num2;
            System.out.print(num3+ " ");
            num1=num2;
            num2=num3;
        }

        //Fibonacci Series with recursion 6: 0 1 1 2 3 5
        Scanner sc1 = new Scanner(System.in);
        System.out.println("\n Enter the length of fibonacci series: ");
        int fiboLength=sc1.nextInt();
        System.out.println("FIBONACCI SERIES WITH RECURSSION: ");
        for(int i=0; i<fiboLength; i++){

            System.out.print(fibo(i)+ " ");
        }

        //Prime Number 67 is a prime number
        Scanner sc2 = new Scanner(System.in);
        System.out.println("\n Enter the number to check if prime or not: ");
        int primeNum=sc2.nextInt();
        int count=0;
        for(int i=1; i<=primeNum; i++) {
            if(primeNum%i == 0){
                count++;
            }
        }

        if(count==2){
            System.out.println(primeNum + " IS A PRIME NUMBER");
        } else {
            System.out.println(primeNum + " IS NOT A PRIME NUMBER");
        }

        //Palindrome Number 6789876 is a Palindrome number
        Scanner sc3 = new Scanner(System.in);
        System.out.println("\n Enter the number to check: ");
        String palinNum=sc3.nextLine();
        String newNum=new String();
        for(int i=palinNum.length()-1; i>=0; i--) {
            newNum=newNum.concat(String.valueOf(palinNum.charAt(i)));

        }

        System.out.println(newNum);
        System.out.println(palinNum);
        if (palinNum.equals(newNum)) {
            System.out.println(palinNum + " IS A PALINDROME NUMBER");
        } else {
            System.out.println(palinNum + " IS NOT A PALINDROME NUMBER");
        }

        //Factorial Number with Recursion 4!=4*3*2*1*0
        Scanner sc4 = new Scanner(System.in);
        System.out.println("Enter the number for which factorial has to be found: ");
        int factNum=sc4.nextInt();
        System.out.println("Factorial of " + factNum + " is: " + fact(factNum));*/

        //Armstrong Number 345=3*3+4*3+5*3
        /*Scanner sc5 = new Scanner(System.in);
        System.out.println("Enter the number for which armstrong has to be check: ");
        int armsNum=sc5.nextInt();
        int y,res=0;
        y=armsNum;
        while(y != 0) {
            int x;
            x=y%10;
            System.out.println("value of x is:" +x);
            res+=(x*x*x);
            System.out.println("value of res is:" +res);
            y=y/10;
            System.out.println("value of y is:" +y);
        }
        System.out.println(armsNum);
        System.out.println(res);
        if(armsNum==res) {
            System.out.println(armsNum+" IS A ARMSTRONG Number");
        } else {
            System.out.println(armsNum+" IS NOT A ARMSTRONG NUMBER");
        }*/

        //Inline 1's and 0's from array of 1's and 0'
        int num[]={1,0,1,0,1,1,0,0,1};
        int count=0;
        for(int i=0; i<num.length; i++) {
            if(num[i]==1){
                count++;
            }
        }
        int resArray[] = new int[num.length];
        for(int i=0; i<num.length; i++) {
            while(count!=0) {
                resArray[i] = 1;
                count--;
                i++;
            }
            resArray[i]=0;
        }
        System.out.println("printing the result : ");
        for(int j=0; j<num.length; j++) {
            System.out.print(resArray[j]+"  ");
        }

        //Smallest number: 20,30,40,21,67,45: 67
        int inp[]={38,30,267,14,4,267};
        int temp=0;
        for(int i=0; i<inp.length-1; i++){
            if(inp[i]<inp[i+1]) {
                temp=inp[i];
                inp[i]=inp[i+1];
                inp[i+1]=temp;
            }
        }
        System.out.println("\nSmallest number is: "+ inp[inp.length-1]);

        //Largest number
        int temp1;
        for(int i=0; i<inp.length-1; i++) {
            if(inp[i]>inp[i+1]) {
                temp1=inp[i];
                inp[i]=inp[i+1];
                inp[i+1]=temp1;
            }
        }
        System.out.println("Largest number: "+ inp[inp.length-1]);

        //Ascending Order
        int ascTemp;
        for(int i=inp.length-1; i>0; i--) {
            for(int j=0; j<i; j++){
                if(inp[j]>inp[j+1]){
                    ascTemp=inp[j];
                    inp[j]=inp[j+1];
                    inp[j+1]=ascTemp;
                }
            }
        }
        System.out.print("\nNumbers in ascending order: ");
        for(int i=0; i<inp.length; i++){
            System.out.print(inp[i]+ "  ");
        }

        //Descending Order
        int dscTemp;
        for(int i=inp.length-1; i>0; i--) {
            for(int j=0; j<i; j++){
                if(inp[j]<inp[j+1]){
                    dscTemp=inp[j];
                    inp[j]=inp[j+1];
                    inp[j+1]=dscTemp;
                }
            }
        }
        System.out.print("\nNumbers in descending order: ");
        for(int i=0; i<inp.length; i++){
            System.out.print(inp[i] + "  ");
        }

        //Print Diagonal number
        int matrix[][]={{1,2,3,4,5,6,7},{1,1,3,4,5,6,7},{1,2,1,4,5,6,7},{1,2,3,1,5,6,7},{1,2,3,4,1,6,7},{1,2,3,4,5,1,7},{1,2,3,4,5,6,1}};
        for(int i=0; i<matrix.length; i++){
            System.out.println(" ");
            for(int j=0; j< matrix.length; j++){
                System.out.print(matrix[i][j]+" ");
            }
        }
        System.out.println("\nNumbers in Diagonal representation: ");
        for(int i=0; i<matrix.length; i++){
            for(int j=0; j< matrix.length; j++){
                if(i==j){//(i>=j),(i<=j)
                    System.out.print(matrix[i][j]+" ");
                }else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }

    }
    /*static int fibo(long n) {
        if(n==0){
            return 0;
        } else if(n==1) {
            return 1;
        }else{
            return (fibo(n - 2) + fibo(n - 1));
        }
    }

    static long fact(long n) {
        if(n==0){
            return 1;
        }
        return n*fact(n-1);//4*3*2*1
    }*/
}
