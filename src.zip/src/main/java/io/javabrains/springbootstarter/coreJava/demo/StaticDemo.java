package io.javabrains.springbootstarter.coreJava.demo;


public class StaticDemo {
    static {
        System.out.println("A");
    }

    {
        System.out.println("B");
    }
    static {
        System.out.println("C");
    }

    StaticDemo() {
        System.out.println("D");
    }

    void test() {
        System.out.println("E");
    }

    public static void main(String[] args) {
        new StaticDemo().test();
    }
}
