package io.javabrains.springbootstarter.coreJava.com.udemy.practiceJavaByBuildingProjects.emailApplication;

import java.util.Scanner;

/**
 * Created by 1554439 on 7/2/2018.
 */
public class EmailApp {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

    }



}
