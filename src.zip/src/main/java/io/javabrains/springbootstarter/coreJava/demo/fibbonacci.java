package io.javabrains.springbootstarter.coreJava.demo;

/**
 * Created by 1554439 on 3/30/2018.
 */
public class fibbonacci {

    public static void main(String[] args) {
        int n=8;
        int fib=fibbo(n);
        System.out.println(fib);
        for(int i=0; i<=n; i++)
            System.out.print(fibbo(i)+" ");
    }

    public static int fibbo(int n){
        if(n==0)
            return 0;
        else if(n==1)
            return 1;
        return fibbo(n-1)+fibbo(n-2);
    }
}
