package io.javabrains.springbootstarter.coreJava.basics;

/**
 * Created by 1554439 on 6/30/2018.
 */
public class Sparrow extends Bird implements Flyable{
    public Sparrow(String name, int age, String color) {
        super(name, age, color);
    }

    public void fly(){
        System.out.println("flying");
    }
}
