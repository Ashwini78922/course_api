package io.javabrains.springbootstarter.coreJava.shape;

/**
 * Created by 1554439 on 7/9/2018.
 */
public class Rectangle {
    int width;
    int length;
    Point origin;

    public Rectangle(){

    }

    public Rectangle(int x, int y){
        width = x;
        length=y;
    }

    public Rectangle(Point originOne, int x, int y){
        origin=originOne;
        width=x;
        length=y;
    }

    public void move(int x, int y){
        origin.x=x;
        origin.y=y;
    }

    public int getArea(){
        return (width*length);
    }
}
