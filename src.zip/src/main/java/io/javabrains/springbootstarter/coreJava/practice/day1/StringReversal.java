package io.javabrains.springbootstarter.coreJava.practice.day1;

import java.util.Scanner;

/**
 * Created by 1554439 on 7/17/2018.
 */
public class StringReversal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the String to reverse :");
        String str= sc.nextLine();
        /*String result;
        result=reverse(str);*/
        System.out.println("Reversed String :"+reverse(str));
    }

    public static String reverse(String str){
        if(str==null ||str.length()<=1)
            return (str);
        else
            return (str.charAt(str.length()-1)+reverse(str.substring(0,str.length()-1)));
    }
}
