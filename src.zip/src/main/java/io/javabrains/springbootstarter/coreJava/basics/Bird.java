package io.javabrains.springbootstarter.coreJava.basics;

/**
 * Created by 1554439 on 6/30/2018.
 */
public abstract class Bird extends Animal{

    public Bird(String name, int age, String color){
        super(name,age,color);
    }

    public abstract void fly();

}
