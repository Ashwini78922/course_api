package io.javabrains.springbootstarter.coreJava;

/**
 * Created by 1554439 on 4/3/2018.
 */
public class Ques1 {
    public static void main(String[] args) {
        String s="tesu";
        boolean b=unique(s);
        if(b)
            System.out.println("All charaters of "+ s+" are unique");
        else
            System.out.println("not unique");
    }
    public static boolean unique(String s){
        char[] c= s.toCharArray();
        for(int i=0; i<c.length; i++){
            for(int j=i+1; j<c.length; j++)
                if(c[i]==c[j])
                    return false;
        }
        return true;
    }
}
