package io.javabrains.springbootstarter.coreJava.sorting;

/**
 * Created by 1554439 on 3/21/2018.
 */
public class HeapSort {
    public static void main(String[] args) {
        int arr[]={23,45,1,35,8,98};
        heapSort(arr);
        for(int i=0; i<arr.length; i++){
            System.out.println(arr[i]);
        }
    }

    public static void heapSort(int arr[]){
        int n=arr.length, temp;

        for(int i=n/2-1; i>=0; i--)
            heapify(arr, n, i);
        for(int j=n-1; j>=0; j--){
            temp=arr[0];
            arr[0]=arr[j];
            arr[j]=temp;
            heapify(arr, j, 0);
        }
    }

    public static void heapify(int arr[], int n, int i){
        int largest=i;
        int left=2*i+1;
        int right=2*i+2;

        if(left<n && arr[left]>arr[largest])
            largest=left;

        if(right<n && arr[right]>arr[largest])
            largest = right;

        if(largest!=i){
            int swap=arr[i];
            arr[i]=arr[largest];
            arr[largest]=swap;
            heapify(arr, n, largest);

        }
    }
}
