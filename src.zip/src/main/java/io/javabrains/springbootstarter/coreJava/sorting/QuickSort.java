package io.javabrains.springbootstarter.coreJava.sorting;

/**
 * Created by 1554439 on 3/21/2018.
 */
public class QuickSort {
    public static void main(String[] args) {
        int arr[]={50,80,90,30,40,10,70};
        quickSort(arr, 0, arr.length-1);
        for (int anArr : arr) System.out.print(anArr + " ");
    }

    public static void quickSort(int arr[], int low, int high){
        if(low<high) {
            int pi = partition(arr, low, high);

            quickSort(arr, low, pi-1);
            quickSort(arr, pi+1, high);
        }
    }

    public static int partition(int arr[], int low, int high){
        int index=low-1;
        int pivot=arr[high];

        for(int j=low; j<high; j++){
            if(arr[j]<=pivot){
                index++;
                int temp=arr[j];
                arr[j]=arr[index];
                arr[index]=temp;
            }
        }
        int swap=arr[high];
        arr[high]=arr[index+1];
        arr[index+1]=swap;
        return index+1;
    }
}
