package io.javabrains.springbootstarter.coreJava;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 1554439 on 4/4/2018.
 */
public class Ques6 {
    public static void main(String[] args) {
        String s="b";
        System.out.println(s);
        compression(s);
    }
    public static void compression(String s){
        List<Integer> l=new ArrayList<>();
        int j=0, count1=1;
        for(int i=0; i<s.length(); i++){
            if(i==0){
                l.add((int) s.charAt(i));
            }
            else if(s.charAt(i)==s.charAt(i-1)){
                if(i==s.length()-1){
                    count1++;
                    l.add(count1);
                }
                count1++;
            }
            else if(s.charAt(i)!=s.charAt(i-1)){
                if(i==s.length()-1){
                    l.add(count1);
                    l.add((int) s.charAt(i));
                    l.add(1);
                }else {
                    l.add(count1);
                    count1 = 1;
                    l.add((int)s.charAt(i));
                }
            }
        }

        System.out.println("Compressed value of string");
        System.out.print(l);
    }
}
