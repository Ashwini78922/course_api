package io.javabrains.springbootstarter.coreJava.demo;


import java.io.*;

public class IODemo {
    public static void main(String[] args) throws IOException {
        /*Scanner sc = new Scanner(new File("C:/Users/1554439.ZONE1-SCBNET/Desktop/Ashwini/course-api/src/main/java/io/javabrains/springbootstarter/file1.txt"));
        System.out.println("Reading and printng from a file:");
        while(sc.hasNext()){
            System.out.println(sc.nextLine());
        }*/

        /*
        * IO Stream
        * 2 Tyypes of stream: Byte Stream and Character stream
        * Byte Stream provides a convenient way of handling input and output of bytes. In a similar way Character stream handles input and output of character
        * Byte Stream is defiend by 2 abstract classes: Input stream and Output stream
        * These 2 abstract classes have concrete classes which handles varoius devices such as disk files and network connections
        * */

        File ft = new File("C:/Users/1554439.ZONE1-SCBNET/Desktop/Ashwini/course-api/src/main/java/io/javabrains/springbootstarter/file1.txt");
        BufferedReader bt = new BufferedReader(new FileReader(ft));
        System.out.println("Reading from using buffered reader");
        String str1;
        while((str1=bt.readLine())!=null){
            System.out.println(str1);

        }
        System.out.println("reading from file ends");

        System.out.println("Enter the line u want to read");
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        String str;
        str=bf.readLine();
        System.out.println("Entered line to be read");
        System.out.println(str);



        System.out.println("Enter the character to be read");
        BufferedReader b1 = new BufferedReader(new InputStreamReader(System.in));
        char text = (char)b1.read();
        System.out.println(text);

        //to write in a file
        BufferedWriter wr = new BufferedWriter(new FileWriter(ft));
        wr.write("Hello, i am new");

        File f1 = new File("C:/Users/1554439.ZONE1-SCBNET/Desktop/Ashwini/course-api/src/main/java/io/javabrains/springbootstarter/file2.txt");
        ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f1));
        os.writeChars("this is another line");
        for(int i=0; i<10; i++){
            os.write(i);
        }
        System.out.println("writing completes");

        System.out.println("reading from file starts");
        ObjectInputStream oi=new ObjectInputStream(new FileInputStream(f1));
        while(f1!=null){
            System.out.println(oi.read());
        }
        System.out.println("reading completes");
        System.out.println("Checking if file exist or not: "+ f1.exists());
        BufferedWriter newText=new BufferedWriter(new FileWriter(new File("C:/Users/1554439.ZONE1-SCBNET/Desktop/Ashwini/course-api/src/main/java/io/javabrains/springbootstarter/file3.txt")));
        newText.write("Hello, i am new");

        /*for(File subFile: f1.listFiles()){
            System.out.println("print the file name: "+subFile.getPath());
        }*/

        bf.close();
        b1.close();
        wr.close();
        os.close();
        newText.close();

    }
}
