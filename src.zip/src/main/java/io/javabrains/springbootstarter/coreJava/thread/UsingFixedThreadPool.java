package io.javabrains.springbootstarter.coreJava.thread;


import io.javabrains.springbootstarter.coreJava.thread.common.LoopRunnableTaskA;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UsingFixedThreadPool {
    public static void main(String[] args) {
        System.out.println("Main thread starts here........");
        ExecutorService executorService= Executors.newFixedThreadPool(3);
        executorService.execute(new LoopRunnableTaskA());
        executorService.execute(new LoopRunnableTaskA());
        executorService.execute(new LoopRunnableTaskA());
        executorService.execute(new LoopRunnableTaskA());
        executorService.execute(new LoopRunnableTaskA());
        executorService.execute(new LoopRunnableTaskA());
        executorService.shutdown();
        //new Thread(new LoopRunnableTaskA()).start();
        System.out.println("Main thread ends here..........");
    }
}
