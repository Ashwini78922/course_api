package io.javabrains.springbootstarter.coreJava;

/**
 * Created by 1554439 on 4/5/2018.
 */
public class Ques7 {
    public static void main(String[] args) {
        int[][] matrix={{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
        int i=0;
        while(i<matrix.length){
            for(int j=0; j<matrix.length; j++)
                System.out.print(matrix[i][j]+" ");
            i++;
        }
        rotate(matrix);
    }
    public static void rotate(int[][] matrix){
        int n=matrix.length;
        int  j=0;
        System.out.println();
        while(j<n){
            for(int i=n-1; i>=0; i--){
                System.out.print(matrix[i][j]+"   ");
            }
            System.out.println();
            j++;
        }
    }
}
