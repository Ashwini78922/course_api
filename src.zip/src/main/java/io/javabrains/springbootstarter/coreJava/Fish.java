package io.javabrains.springbootstarter.coreJava;

/**
 * Created by 1554439 on 6/27/2018.
 */
public class Fish {

    String fin;
    int fishCount;

    public Fish(){
        fin="Beautiful";
        fishCount=2;
    }

    public Fish(String newFin){
        fin=newFin;
        fishCount=6;
    }

    Fish(String newValue, int newCount){
        fin=newValue;
        fishCount=newCount;
    }

    void swim(){
        System.out.println("swimming");
    }

    void swim(String fin){
        System.out.println("fish can't swim without fins");
    }

}
