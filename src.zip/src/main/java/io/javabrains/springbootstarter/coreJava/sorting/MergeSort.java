package io.javabrains.springbootstarter.coreJava.sorting;

/**
 * Created by 1554439 on 3/20/2018.
 */
public class MergeSort {
    public static void main(String[] args) {
        int arr[]={34,56,2,1,56,78,98};
        mergeSort(arr);
        for(int i=0; i<arr.length; i++)
            System.out.println(arr[i]);
    }

    public static void mergeSort(int arr[]){
        int len=arr.length;
        if(len>1) {
            int mid = len / 2;

            int LeftArray[] = new int[mid];
            int RightArray[] = new int[len - mid];

            for (int i = 0; i < LeftArray.length; i++) {
                LeftArray[i] = arr[i];
            }
            for (int j = mid; j < mid+RightArray.length; j++) {
                RightArray[j-mid] = arr[j];
            }

            mergeSort(LeftArray);
            mergeSort(RightArray);
            merge(LeftArray, RightArray, arr);
        }
    }
    public static void merge(int lArray[], int rArray[], int arr[]){
        int nl,nr,i=0,j=0,k=0;
        nl=lArray.length;
        nr=rArray.length;

        while(j<nl && k<nr){
            if(lArray[j]<rArray[k]) {
                arr[i] = lArray[j];
                i++;
                j++;
            }
            else{
                arr[i]=rArray[k];
                i++;
                k++;
            }
        }
        while(j<nl){
            arr[i] = lArray[j];
            i++;
            j++;
        }
        while(k<nr){
            arr[i] = rArray[k];
            i++;
            k++;
        }
    }
}
