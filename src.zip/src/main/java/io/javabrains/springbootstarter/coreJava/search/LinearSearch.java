package io.javabrains.springbootstarter.coreJava.search;

/**
 * Created by 1554439 on 3/19/2018.
 */
public class LinearSearch {
    public static void main(String[] args) {
        int arr[]={10,20,45,7,4};
        int x=10;
        int i=lSearch(arr,x);
        if(i<0)
            System.out.println("Number not found");
        else
            System.out.println("Number "+x+" found at index: "+i);
    }

    public static int lSearch(int arr[], int x){
        int length=arr.length;
        for(int i=0; i<length; i++){
            if(x==arr[i])
                return i;
        }
        return -1;
    }
}
