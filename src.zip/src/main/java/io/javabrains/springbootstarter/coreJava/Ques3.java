package io.javabrains.springbootstarter.coreJava;

/**
 * Created by 1554439 on 4/3/2018.
 */
public class Ques3 {
    public static void main(String[] args) {
        String str="A Kumari testing done            ";//19,16
        char[] c=str.toCharArray();
        int trueLength=findLastCharacter(c)+1;//16
        replaceWhitespace(c, trueLength);
        for(int i=0; i<c.length; i++){
            System.out.print(c[i]);
        }

    }
    public static int findLastCharacter(char[] c){
        for(int i=c.length-1; i>=0; i--){
            if(c[i]!=' ')
                return i;
        }
        return -1;
    }

    public static void replaceWhitespace(char[] c, int trueLength){//16
        System.out.println("length of c"+c.length);//19
        int count=0;
        for(int i=0; i<trueLength; i++){
            if(c[i]==' ')
                count++;//2
        }
        int index=trueLength+count*2;//20
        System.out.println(index);
       /* if(trueLength<c.length)
            c[trueLength]='\0';*/
        for(int i=trueLength-1; i>=0; i--){
            if(c[i]==' '){
                c[index-1]='0';
                c[index-2]='2';
                c[index-3]='%';
                index=index-3;
            }
            else{
                c[index-1]=c[i];
                index--;
            }
        }
    }
}
