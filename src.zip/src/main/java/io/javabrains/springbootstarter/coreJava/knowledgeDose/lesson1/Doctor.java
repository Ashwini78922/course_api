package io.javabrains.springbootstarter.coreJava.knowledgeDose.lesson1;

/**
 * Created by 1554439 on 7/1/2018.
 */
public class Doctor extends Employee {
    public Doctor(int id, String name, String department, boolean working) {
        super(id, name, department, working);
        System.out.println("Doctor in action ....");
    }

    //Doctor

    public void prescribeMedicine(){
        System.out.println("wrinting medicine...");
    }

    public void digonsisPatient(){
        System.out.println("Checking Patient");
    }

    public void performDuties(){
        digonsisPatient();
        prescribeMedicine();
    }
}
