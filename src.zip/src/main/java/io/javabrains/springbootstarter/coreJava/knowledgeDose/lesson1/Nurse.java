package io.javabrains.springbootstarter.coreJava.knowledgeDose.lesson1;

/**
 * Created by 1554439 on 7/1/2018.
 */
public class Nurse extends Employee {
    public Nurse(int id, String name, String department, boolean working) {
        super(id, name, department, working);
        System.out.println("Nurse in action....");
    }

    //Nurse
    public void checkVitalSigns(){
        System.out.println("Checking vitals...");
    }

    public void drawBlood(){
        System.out.println("drawing blood...");
    }

    public void cleanPatientArea(){
        System.out.println("cleaning patient area...");
    }

    public void performDuties(){
        checkVitalSigns();
        drawBlood();
        cleanPatientArea();
    }
}
