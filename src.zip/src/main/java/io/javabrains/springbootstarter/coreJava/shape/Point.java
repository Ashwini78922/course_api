package io.javabrains.springbootstarter.coreJava.shape;

/**
 * Created by 1554439 on 7/9/2018.
 */
public class Point {

    int x;
    int y;
     public Point(int x, int y){
         this.x=x;
         this.y=y;
     }
}
