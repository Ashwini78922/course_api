package io.javabrains.springbootstarter.coreJava.sapientOnlineTest;

/**
 * Created by 1554439 on 3/13/2018.
 */
public abstract class AbstractTest {

    public abstract void t();
}
