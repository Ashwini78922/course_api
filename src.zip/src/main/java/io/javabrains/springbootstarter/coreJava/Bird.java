package io.javabrains.springbootstarter.coreJava;

/**
 * Created by 1554439 on 6/30/2018.
 */
public class Bird {

    public int age;
    public String name;
    public String wingColor;

    public Bird(int age, String name, String wingColor){
        this.age=age;
        this.name=name;
        this.wingColor=wingColor;
    }

    public void birdie(){
        System.out.println(age);
        System.out.println(name);
        System.out.println(wingColor);
    }

    public void fly(){
        System.out.println("flying");
    }
}
