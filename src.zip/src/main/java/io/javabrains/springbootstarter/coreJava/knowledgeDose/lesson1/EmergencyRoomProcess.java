package io.javabrains.springbootstarter.coreJava.knowledgeDose.lesson1;

/**
 * Created by 1554439 on 7/1/2018.
 */
public class EmergencyRoomProcess{
    public static void main(String args[]){
        HospitalManagement ERDirector=new HospitalManagement();
        Employee dezee =new Nurse(1001, "dezee", "reception", true);
        ERDirector.callUpon(dezee);

        Employee drea=new Doctor(1002,"drea","room1",true);
        ERDirector.callUpon(drea);
    }
}
