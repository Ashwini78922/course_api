package io.javabrains.springbootstarter.coreJava.thread;


import java.util.concurrent.TimeUnit;

public class ThreadRunnableDemo {
    public static void main(String[] args) {
        System.out.println("Mian thread starts here");
        new myRunnable();
        new myRunnable();
        System.out.println("Main thread ends here");
    }
}

class myRunnable implements Runnable {

    private static int count=0;
    private int id;

    @Override
    public void run() {
        for(int i=1; i<=10; i++){
            System.out.println("<"+id+"> "+"Inside runnable : " + i);
            try {
                TimeUnit.MILLISECONDS.sleep(2000);
            } catch (InterruptedException e) {

            }
        }
    }
    public myRunnable() {
        this.id=++count;
        new Thread(this).start();
    }
}
