package io.javabrains.springbootstarter.coreJava.basics;

/**
 * Created by 1554439 on 6/30/2018.
 */
public class Zoo {
    public static void main(String args[]){
        /*Animal dog=new Animal("tomy", 2, "white");
        dog.speak();*/


        Bird sparrow1=new Sparrow("sparrow", 3, "greyish");
        //sparrow1.fly();

        Bird cock1=new Cock("cock",4,"red");
        //cock1.fly();

        flyBird(sparrow1);
        flyBird(cock1);

        Flyable a1=new Sparrow("sparr", 3, "blue");
        a1.fly();

    }

    public static void flyBird(Bird bird){
        bird.fly();
    }
}
