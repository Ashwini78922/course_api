package io.javabrains.springbootstarter.coreJava.sorting;


public class SelectionSort {

    public static void main(String[] args) {
        int arr[] = {7, 10, 10, 56, 32, 4, 2, 5};
        selection(arr);
        for (int anArr : arr) {
            System.out.print(anArr + " ");
        }
    }

    public static void selection(int arr[]) {
        int temp, index, len = arr.length;
        for (int anArr : arr) {
            System.out.print(anArr + " ");
        }
        System.out.println();

        for (int i = 0; i < len - 1; i++) {
            index = i;
            for (int j = i + 1; j < len; j++) {
                if (arr[index] > arr[j])
                    index = j;
            }
            temp = arr[i];
            arr[i] = arr[index];
            arr[index] = temp;

            System.out.print(i + 1 + " Iteration:  ");
            for (int anArr : arr) {
                System.out.print(anArr + " ");
            }
            System.out.println("");
        }
    }
}
