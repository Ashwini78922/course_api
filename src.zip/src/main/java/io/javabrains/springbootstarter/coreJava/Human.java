package io.javabrains.springbootstarter.coreJava;

/**
 * Created by 1554439 on 6/30/2018.
 */
public class Human {

    String name;
    int age;
    String eyeColor;
    int height;

    public Human(String name1, int age1, String eyeColor1, int height1){
        name=name1;
        age=age1;
        eyeColor=eyeColor1;
        height=height1;

    }

    void speak(){
        System.out.println("Hi i am "+ name);
        System.out.println("i am "+age+" years old");
        System.out.println("My eye color is "+ eyeColor);
        System.out.println("i am "+height+" inches tall");
    }

    void see(){
        System.out.println("seeing");
    }
    void talk(){
        System.out.println("talking");
    }
}
