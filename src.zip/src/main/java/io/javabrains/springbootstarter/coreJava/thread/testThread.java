package io.javabrains.springbootstarter.coreJava.thread;


public class testThread extends Thread{
    public void run(){
        for (int i=0; i<5; i++){
            try{
                Thread.sleep(500);
            }catch(InterruptedException e){
                System.out.println(e);
            }

            System.out.println("thread name" + Thread.currentThread());
            System.out.println(i);
        }
    }
    public static void main(String[] args) {
        testThread t1= new testThread();
        testThread t2=new testThread();
        t1.start();
        t2.start();
    }
}
