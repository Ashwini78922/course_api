package io.javabrains.springbootstarter.coreJava;

/**
 * Created by 1554439 on 6/30/2018.
 */
public class Animal {
    int age;
    String name;
    String color;

    public Animal(int age,String name, String color){
        this.age=age;
        this.name=name;
        this.color=color;

    }

    public void character(){
        System.out.println("i am "+ name);
        System.out.println("my age is "+ age);
        System.out.println(color+ " is my color");
    }
    public void speak(){
        System.out.println("speaking");
    }

    public void talk(){
        System.out.println("talking");
    }
}
