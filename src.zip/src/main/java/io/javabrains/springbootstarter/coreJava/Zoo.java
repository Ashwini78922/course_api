package io.javabrains.springbootstarter.coreJava;

/**
 * Created by 1554439 on 6/30/2018.
 */
public class Zoo {
    public static void main(String[] args) {
        Animal dog = new Animal(4, "tom", "white");
        Animal cow = new Animal(5, "cow", "black");

        dog.character();
        cow.character();

        Bird crow=new Bird(1,"crowie", "black");
        crow.birdie();
    }


}
