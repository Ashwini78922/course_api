package io.javabrains.springbootstarter.coreJava.basics;

/**
 * Created by 1554439 on 6/30/2018.
 */
public interface Flyable {
    public void fly();
}
