package io.javabrains.springbootstarter.coreJava.sorting;

/**
 * Created by 1554439 on 3/28/2018.
 */
public class MinimumLengthUnsortedSubarray {
    public static void main(String[] args) {
        int arr[]={6, 7, 15, 25, 1,0,  30, 40, 50};
        int min=MinIndex(arr);
        int max=MaxIndex(arr);
        if(min==max)
            System.out.println("Array is already sorted");
        else
            System.out.println("Unsorted subarray lies between the indexes "+min+" and "+max);
    }
    public static int MinIndex(int arr[]){
        int len=arr.length;
        for(int i=0; i<len; i++)
            for(int j=i+1; j<len; j++)
                if(arr[i]>arr[j])
                    return i;
        return 0;
    }
    public static int MaxIndex(int arr[]){
        int len=arr.length;
        for(int i=len-1; i>=0; i--)
            for(int j=i-1; j>=0; j--)
                if(arr[i]<arr[j])
                    return i;
        return 0;
    }
}



