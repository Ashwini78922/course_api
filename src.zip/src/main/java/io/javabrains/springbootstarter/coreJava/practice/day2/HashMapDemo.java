package io.javabrains.springbootstarter.coreJava.practice.day2;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by 1554439 on 7/17/2018.
 */
public class HashMapDemo {
    public static void main(String[] args) {
        HashMap<String, Integer> map=new HashMap<>();

        print(map);

        map.put("A", 2);
        map.put("B", 4);
        
        print(map);

        if(map.containsKey("A")){
            Integer a= map.get("A");
            System.out.println("Value for the key A is "+a);
        }else{
            System.out.println("the respective key is not availeble");
        }
    }

    public static void print(HashMap map){
        if(map.isEmpty()){
            System.out.println("Map is empty");
        }else{
            System.out.println(map);
        }
    }
}
