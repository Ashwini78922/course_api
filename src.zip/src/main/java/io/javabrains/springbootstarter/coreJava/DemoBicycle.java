package io.javabrains.springbootstarter.coreJava;

/**
 * Created by 1554439 on 6/26/2018.
 */
public class DemoBicycle {
    public static void main(String[] args) {
        /*Bicycle b1= new Bicycle();
        Bicycle b2= new Bicycle();*/

        /*b1.gear=2;
        b1.cadence=0;
        b1.speed=3;

        b2.gear=1;
        b2.cadence=9;
        b2.speed=9;*/

       /* b1.updateCadence(0);
        b1.selectGear(2);
        b1.applyBrakes(5);
        b1.printBicycle();

        b2.updateCadence(9);
        b2.speedIncrement(5);
        b2.selectGear(1);
        b2.printBicycle();*/
    }
}
