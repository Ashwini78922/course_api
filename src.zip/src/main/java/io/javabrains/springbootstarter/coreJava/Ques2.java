package io.javabrains.springbootstarter.coreJava;

/**
 * Created by 1554439 on 4/3/2018.
 */
public class Ques2 {
    public static void main(String[] args) {
        String s1="test";
        String s2="testtest";
        int p=perm(s1,s2);
    }
    public static int perm(String s1, String s2){

        return 0;
    }
}
