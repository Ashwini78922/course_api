package io.javabrains.springbootstarter.coreJava;

/**
 * Created by 1554439 on 6/30/2018.
 */
public class Earth {
    public static void main(String[] args) {
        Human h1= new Human("rtr", 24, "black", 5);
        Human h2= new Human("tommy", 26, "brown", 6);
        Human h3= new Human("arson", 30, "blue", 7);

        h1.speak();
        h2.speak();
        h3.speak();
    }
}
