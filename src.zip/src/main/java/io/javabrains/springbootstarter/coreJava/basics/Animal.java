package io.javabrains.springbootstarter.coreJava.basics;

/**
 * Created by 1554439 on 6/30/2018.
 */
public class Animal {

    public String name;
    public int age;
    public String height;

    public Animal(String name, int age, String height){
        this.name=name;
        this.age=age;
        this.height=height;
    }

    public void speak(){
        System.out.println("Animal "+name);
        System.out.println("age "+age);
        System.out.println("height "+height);
    }

    public void eat(){
        System.out.println("eating ...");
    }

    public void sleep(){
        System.out.println("sleeping ...");
    }
}
