package io.javabrains.springbootstarter.coreJava.practice.day1;

import java.util.Scanner;

/**
 * Created by 1554439 on 7/17/2018.
 */
public class Fibbonaci {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the fibbonacci number ");
        int n= sc.nextInt();
        for (int i=0; i<=n; i++){
            System.out.print(fibo(i)+" ");
        }
    }

    public static int fibo(int n){
        if(n==0)
            return 0;
        else if(n==1 || n==2)
            return 1;
        else
            return (fibo(n-1)+fibo(n-2));
    }
}
