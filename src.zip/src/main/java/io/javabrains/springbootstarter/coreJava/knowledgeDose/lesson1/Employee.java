package io.javabrains.springbootstarter.coreJava.knowledgeDose.lesson1;

/**
 * Created by 1554439 on 7/1/2018.
 */
public abstract class Employee {
    public int id;
    public String name;
    public String department;
    public boolean working;

    public Employee(int id, String name, String department, boolean working){
        this.id=id;
        this.name=name;
        this.department=department;
        this.working=working;
    }

    public abstract void performDuties();

    private String StringTo(){
        return ("id "+id+"name :"+name+"department :"+department+"working :"+working);
    }
}
