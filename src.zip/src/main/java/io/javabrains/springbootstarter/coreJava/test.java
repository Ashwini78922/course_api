package io.javabrains.springbootstarter.coreJava;

//import java.lang.reflect.Method;
/**
 * Created by 1554439 on 5/24/2018.
 */
public class test {

    public test(){

    }

    public test(int x){
        System.out.println("second constructor");
    }
    public static void main(String[] args) {
        System.out.println("started");
        test t=new test();
        test t1=new test(5);

    }

    {
        System.out.println("One");
    }
    {
        System.out.println("two");
    }
}

