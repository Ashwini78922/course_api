package io.javabrains.springbootstarter.coreJava.demo;


import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {
    public static void main(String[] args) {
        //using the interface type (Set) on as the reference type, and concrete implementation (HashSet, LinkedHashSet, TreeSet, etc)
        Set s = new HashSet<>();
        s.add(34);
        s.add("A");
        s.add("Z");
        s.add("R");
        s.add("sdsd");
        s.add('v');
        System.out.println(s.add("R")); //false
        System.out.println(s.add(null));
        System.out.println(s.add(null));
        System.out.println(s.add("null"));
        System.out.println("HASH SET: "+s);

        LinkedHashSet linkedSet = new LinkedHashSet();
        linkedSet.add("AS");
        linkedSet.add(56);
        linkedSet.add("C");
        linkedSet.add(89);
        linkedSet.add('d');
        System.out.println(linkedSet.add('d'));
        System.out.println(linkedSet.add(null));
        System.out.println(linkedSet.add("null"));
        System.out.println(linkedSet.add(null));
        System.out.println("LINKEDHASHSET: "+linkedSet);

        TreeSet treeSet = new TreeSet<>(); //backed by tree map
        //System.out.println(treeSet.add(null));// null is not allowed in treeSet
        treeSet.add("Z");
        treeSet.add("D");
        treeSet.add("F");
        treeSet.add("A");
        System.out.println(treeSet.add("A"));
        System.out.println(treeSet.add("null"));
        //System.out.println(treeSet.add(null)); //not throw compile time error but will throws NPE
        System.out.println("TREESET : " +treeSet);
    }
}
