package io.javabrains.springbootstarter.coreJava;

/**
 * Created by 1554439 on 6/26/2018.
 */
public class Bicycle {
    private int cadence;
    private int gear;
    private int speed;

    private int id;

    private static int noOfBicycle=0;

    public Bicycle(int cadence, int gear, int speed){
        this.cadence=cadence;
        this.gear=gear;
        this.speed=speed;
        id=++noOfBicycle;
    }

    public int getId(){
        return id;
    }

    public static int getNoOfBicycle(){
        return noOfBicycle;
    }

    public void setCadence(int newCadence){
        cadence=newCadence;
    }

    public int getCadence(){
        return cadence;
    }

    public void setGear(int newGear){
        gear=newGear;
    }

    public int getGear(){
        return gear;
    }

    public int getSpeed(){
        return speed;
    }

    public void applyBrakes(int decrement){
        speed-=decrement;
    }

    public void speedup(int increment){
        speed+=increment;
    }
}
