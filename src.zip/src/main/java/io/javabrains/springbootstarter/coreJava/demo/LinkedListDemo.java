package io.javabrains.springbootstarter.coreJava.demo;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class LinkedListDemo {
    public static void main(String[] args) {
        LinkedList linkedlist = new LinkedList<>();
        System.out.println(linkedlist.add("A"));
        linkedlist.add("B");
        System.out.println(linkedlist);

        System.out.println(linkedlist.getFirst());
        System.out.println(linkedlist.getLast());

        List arrayList =new ArrayList<>();
        arrayList.add("Apple");
        arrayList.add(2);
        System.out.println(arrayList);

        linkedlist.addAll(arrayList);
        System.out.println(linkedlist);

        arrayList.add(0, linkedlist);
        System.out.println(arrayList);

        /*linkedlist.add(1, arrayList);
        System.out.println(linkedlist);
        linkedlist.addAll(0, linkedlist);
        System.out.println(linkedlist);

        arrayList.addAll(0, linkedlist);
        System.out.println(arrayList);*/

        LinkedList<String> strList =new LinkedList<>();
        strList.add("sjk");
        strList.add("bye");
        System.out.println(strList.size());
        System.out.println(strList.hashCode());
        Object o;
        System.out.println(o=strList.clone());
        System.out.println("Object"+o);
        strList.set(1, "45");
        System.out.println(strList);
        System.out.println("Last element" +strList.getLast());
        strList.add(2, "two");
        strList.add(1, "one");
        System.out.println(strList);
        strList.add(5,"fail");
        System.out.println(strList);

        List newArray = new ArrayList();
        newArray.add('D');
        newArray.add(45);
        newArray.add("Good");
        System.out.println(newArray);
        newArray.set(0, 78);
        newArray.set(1, "K");
        System.out.println("new Array" +newArray);
        newArray.add(1, 100);
        newArray.add(3, "T");
        newArray.add(5, "six");
        System.out.println(newArray);

    }
}
