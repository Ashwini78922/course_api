package io.javabrains.springbootstarter;

/**
 * Created by 1554439 on 4/5/2018.
 */
public class Ques8 {
    public static void main(String[] args) {
        int[][] matrix= {{1,2,0,4,5,6},{7,8,9,1,2,3},{1,2,5,0,5,6},{1,2,9,4,0,6},{1,2,8,4,5,6}};
        int row=matrix.length;

        System.out.println(row);
        for (int[] aMatrix : matrix) {
            for (int j = 0; j < 6; j++) {
                System.out.print(aMatrix[j] + " ");
            }
            System.out.println();
        }
        zeroMatrix(matrix);

    }
    public static void zeroMatrix(int[][] matrix){
        int count=0;
        int[] col= new int[count];

        for (int[] aMatrix : matrix)
            for (int j = 0; j < 6; j++)
                if (aMatrix[j] == 0) {
                    col[count]=j;
                    count++;
                }
        System.out.println("number of zero's in this matrix: " +count);
        for(int i=0; i<col.length; i++){
            System.out.println(col[i]);
        }

    }
}
